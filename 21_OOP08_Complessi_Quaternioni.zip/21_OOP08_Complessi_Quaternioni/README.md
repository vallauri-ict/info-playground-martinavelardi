# info-playground-martinavelardi-OOP08
_Velardi Martina 4^B inf_
### Ottavo esercizio sulle OOP. Esercizio 2 delle dispense "OOP02".